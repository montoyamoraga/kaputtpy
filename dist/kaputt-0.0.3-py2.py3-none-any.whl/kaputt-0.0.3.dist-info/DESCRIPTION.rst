# kaputtpy

## About

This is a project by [Aarón Montoya-Moraga](http://montoyamoraga.io/).

kaputt.py is a Python library for making stuff go kaputt.

## Reference

* [Packaging Python Projects](https://packaging.python.org/tutorials/packaging-projects/)

## License

MIT


